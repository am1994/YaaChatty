import 'package:flutter/material.dart';
import 'package:flash_chat/screens/welcome_screen.dart';
import 'package:flash_chat/screens/login_screen.dart';
import 'package:flash_chat/screens/registration_screen.dart';
import 'package:flash_chat/screens/chat_screen.dart';
import 'package:flash_chat/screens/online_screen.dart';
void main() => runApp(FlashChat());

class FlashChat extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(

          cursorColor: Colors.black,
          iconTheme: IconThemeData(
            color: Colors.black
          ),
          appBarTheme:AppBarTheme(
            elevation: 15.0,
            color: Colors.white,
            iconTheme: IconThemeData(
              color: Colors.black
            ),
            actionsIconTheme: IconThemeData(
              color: Colors.black
            ) ,
            textTheme: TextTheme(
              title: TextStyle(color: Colors.black,
                             fontWeight: FontWeight.bold,
                             fontSize: 20.0),
            )
          ),

        textTheme: TextTheme(
          //body1: TextStyle(color: Colors.lightBlueAccent),
        ),

      ),
      initialRoute: WelcomeScreen.id,
      routes: {
        WelcomeScreen.id: (context) => WelcomeScreen(),
        LoginScreen.id: (context) => LoginScreen(),
        RegistrationScreen.id: (context) => RegistrationScreen(),
        ChatScreen.id: (context) => ChatScreen(),
        OnlineScreen.id: (context) => OnlineScreen(),



      }
    );
  }
}
