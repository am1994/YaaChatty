import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/rendering.dart';
import 'package:flash_chat/components/avatar.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flash_chat/constants.dart';
final  _firestore = Firestore.instance;

final _auth=FirebaseAuth.instance;
FirebaseUser loggedInUser;
//I have changed (avatar - profile image)
class ProfileScreen extends StatefulWidget {
final userUid;
ProfileScreen(this.userUid);


  @override
  _ProfileScreenState createState() => _ProfileScreenState(userUid);
}

class _ProfileScreenState extends State<ProfileScreen> {
  final usrUid;
  _ProfileScreenState(this.usrUid);
  @override
  void initState() {
    super.initState();
    getCurrentUser();  }

  void getCurrentUser() async{
    try{
      final user = await _auth.currentUser();
      if(user != null){
        loggedInUser = user;
        print(loggedInUser.email);
      }}catch(e){
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundBodyColor,

      appBar: AppBar(
             title: Text("Profile"),
           ),
      body:  Center(
                    child: StreamBuilder<QuerySnapshot>(
                       stream: _firestore.collection('users').snapshots(),
                       builder: (context, snapshot){
                         if(!snapshot.hasData){
                           return Center(
                             child: CircularProgressIndicator(
                               backgroundColor: Colors.lightBlueAccent,
                             ),
                           );
                         }
                         final List<DocumentSnapshot> infos = snapshot.data.documents;
                         int i = 0;
                         var nickname ='';
                         var photoUrl = '';
                         var age ='';
                         var about = '';

                         while(  i  <  infos.length){
                           if(infos[i]['id'] == usrUid){
                             nickname = infos[i]['nickname'];
                             photoUrl = infos[i]['pic_url'];
                             age = infos[i]['age'];
                             about = infos[i]['about'];
                           }
                           i++;
                         }
                         return Padding(
                           padding: const EdgeInsets.only(top: 50.0),
                           child: Column(
                             children: <Widget>[
                               photoUrl != ''
                                   ? Material(
                                 child: CachedNetworkImage(
                                   placeholder: (context, url) => Container(
                                     child: CircularProgressIndicator(
                                       strokeWidth: 2.0,
                                       valueColor: AlwaysStoppedAnimation<Color>(themeColor),),
                                     width: 90.0,
                                     height: 90.0,
                                     padding: EdgeInsets.all(20.0),),
                                   imageUrl: photoUrl,
                                   width: 90.0,
                                   height: 90.0,
                                   fit: BoxFit.cover,
                                 ),
                                 borderRadius: BorderRadius.all(Radius.circular(45.0)),
                                 clipBehavior: Clip.hardEdge,
                               ) : Avatar(40.0,Colors.lightBlueAccent,Colors.white),
                               SizedBox(
                                 height: 8.0,
                               ),
                               Text(nickname != null ? nickname : 'not written',style: TextStyle(fontFamily: 'Pacifico',fontSize: 24),),
                               SizedBox(
                                 height: 8.0,
                               ),
                               Text(age != null ? age : 'not written',style: TextStyle(fontSize: 12),),
                               SizedBox(
                                 height: 8.0,
                               ),
                               Text(about != null ? about : 'not written',style: TextStyle(fontSize: 10),),

                              ],
                           ),
                         );
                       },
                     )
            ),


    );
  }
}
