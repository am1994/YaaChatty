import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'direct_chat_screen.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flash_chat/constants.dart';
import 'package:flash_chat/components/avatar.dart';
import 'package:flash_chat/screens/profile_screen.dart';
FirebaseUser loggedInUser;
final  _firestore = Firestore.instance;
final _auth=FirebaseAuth.instance;

//TODO redesign online screen
class OnlineScreen extends StatefulWidget {
  static String id = 'online_screen';


  @override
  _OnlineScreenState createState() => _OnlineScreenState();
}

class _OnlineScreenState extends State<OnlineScreen> {

  @override
  void initState() {
    super.initState();
    getCurrentUser();

  }
  void getCurrentUser() async{
    try{
      final user = await _auth.currentUser();
      if(user != null){
        loggedInUser = user;
        // addConnectedUser();
        print(loggedInUser.email);
      }}catch(e){
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundBodyColor,
      appBar: AppBar(
          leading:null,
           title: Text("online"),
         ),

          body: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                UserStream(),
            ],
            ),
        ),
      );
  }


}

class OnlinePerson extends StatelessWidget {
  //TODO connection state {snapshot.connectionState} (result : message = ConnectionState.active/waiting)

  OnlinePerson(this.email,this.id,this.nickname,this.photoUrl,this.about);
  final String email;
  final String id;
  final String nickname;
  final String photoUrl;
  final String about;

  @override
  Widget build(BuildContext context) {
    return Container(

      child: Stack(
          alignment: Alignment.center,
          children:<Widget>[


          Card(
           color: kPartnerMessageBubble,
           shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20.0),
            ),
            margin: EdgeInsets.only(top: 20.0),
            elevation: 10.0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                      Column(
                        children: <Widget>[
                          SizedBox(height: 40.0,),
                        Text(nickname,style: TextStyle(fontFamily: 'Pacifico',fontSize: 25.0,
                            color: Colors.white,
                            fontWeight: FontWeight.bold)),
                        SizedBox(
                          height: 8.0,),
                       Text(about,style: TextStyle(fontSize: 14.0,color: Colors.white,
                            fontWeight: FontWeight.bold)),
                        ],
                      ),

                     Row(
                       mainAxisAlignment: MainAxisAlignment.spaceAround,
                       children:<Widget>[
                         RaisedButton(
                           elevation: 10.0,
                           shape: RoundedRectangleBorder(
                             borderRadius: BorderRadius.circular(20.0),
                           ),
                              onPressed: (){
                                Navigator.push(context,MaterialPageRoute(builder: (context)
                                => ProfileScreen(id),),);},
                           child: Text('Profile', style: kOnlineTextButtonTheme),
                           ),
                          SizedBox(
                            width: 8.0,
                          ),

                          RaisedButton(
                            elevation: 10.0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                              onPressed: (){
                                Navigator.push(context,MaterialPageRoute(builder: (context)
                                => DirectChatScreen(nickname,id),),);},
                            child: Text('Chat', style: kOnlineTextButtonTheme,),
                              ),
                        ]
                     ),



//                CircleAvatar(
//                  radius: 10.0,
//                  backgroundColor:  Colors.green,
//                ),
              ],
          ),
        //  ),
        ),

            //photo
            Positioned(
              top:0 ,
              child: photoUrl != ''
                  ? Material(
                elevation: 30.0,
                child: CachedNetworkImage(
                  placeholder: (context, url) => Container(
                    child: CircularProgressIndicator(
                      strokeWidth: 2.0,
                      valueColor: AlwaysStoppedAnimation<Color>(themeColor),),
                    width: 24.0,
                    height: 90.0,
                    padding: EdgeInsets.all(20.0),),
                  imageUrl: photoUrl,
                  width: 70.0,
                  height: 70.0,
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.all(Radius.circular(45.0)),
                clipBehavior: Clip.antiAliasWithSaveLayer,
              ) : Avatar(35.0,Colors.white,Colors.black),
            ),

      ]
      ),
    );
  }
}

class UserStream extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return  StreamBuilder<QuerySnapshot>(
      stream: _firestore.collection('users').snapshots(),
      builder:  (context, snapshot) {
        if(!snapshot.hasData){
          return Center(
            child: CircularProgressIndicator(
              backgroundColor: Colors.lightBlueAccent,
            ),
          );
        }
        final users = snapshot.data.documents;
        List<OnlinePerson> onlinePerson = [];
        for(var user in users){
          //check if user ID == current user ID , if no show it
         if (user['id'] != loggedInUser.uid) {
           final nickName = user['nickname'];
           final userID = user['id'];
           final url = user['pic_url'];
           final userEmail = user['email'];
           final about = user['about'];
           final onlineUser = OnlinePerson(userEmail,userID,nickName,url,about);
           onlinePerson.add(onlineUser);
         }
        }
        return Expanded(
          child: GridView.count(
            primary: false,
            padding: const EdgeInsets.all(5),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            crossAxisCount: 2,
            children: onlinePerson,
          ),
        );

      },
    );
  }
}